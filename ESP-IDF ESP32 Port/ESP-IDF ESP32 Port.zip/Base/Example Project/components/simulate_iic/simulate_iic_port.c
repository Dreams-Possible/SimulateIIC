#include"simulate_iic.h"
#ifdef SIMULATE_IIC_H

//port init
void port_init();
//scl write
void scl_write(uint8_t bit);
//sda write
void sda_write(uint8_t bit);
//sda read
uint8_t sda_read();

//port init
void port_init()
{
    //sda

    //scl

    return;
}

//scl write
void scl_write(uint8_t bit)
{

    return;
}

//sda write
void sda_write(uint8_t bit)
{

    return;
}

//sda read
uint8_t sda_read()
{

    return 0;
}

#endif//#ifdef SIMULATE_IIC_H
